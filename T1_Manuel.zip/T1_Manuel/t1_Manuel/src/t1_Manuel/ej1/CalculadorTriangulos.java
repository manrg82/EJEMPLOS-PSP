package t1_Manuel.ej1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CalculadorTriangulos {
	public static void main(String[] args) {
		if(args.length==0) {
			throw new IllegalArgumentException("ARGUMENTOS INVALIDOS");
		}
		File fl=new File("./files/triangulos.txt");
		int base=Integer.parseInt(args[0]);
		int altura=Integer.parseInt(args[1]);
		int area=(base*altura)/2;
		String contenido="Base: "+base+", Altura: "+altura+", Area: "+area;
		try {
			BufferedWriter bf=new BufferedWriter(new FileWriter(fl));
			bf.write(contenido);
			bf.close();
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
