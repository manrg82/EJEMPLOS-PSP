package t1_Manuel.ej1;

import java.io.IOException;
import java.util.ArrayList;

public class LanzadorTriangulos {

	public static void main(String[] args) {
		ProcessBuilder pb;
		String classpath=".;./bin";
		pb=new ProcessBuilder("java","-cp",classpath,"1","2");
		ArrayList<Process> lista=new ArrayList<Process>();
		for(int i=0;i<6;i++) {
			try {
				lista.add(pb.start());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
