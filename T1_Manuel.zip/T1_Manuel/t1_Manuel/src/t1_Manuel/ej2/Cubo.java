package t1_Manuel.ej2;

public class Cubo implements Runnable{
	private static Cubo instance;
	private int capacidad;
	private final int CAP_MAX=5;
	private Cubo() {
		this.capacidad=0;
	}
	private synchronized static void createInstance() {
		if(instance==null) {
			instance=new Cubo();
		}
	}
	public static synchronized Cubo getInstance() {
		if(instance==null) {
			createInstance();
		}
		
		return instance;
	}
	public synchronized void addAgua(int amt) {
		if(amt<=(this.CAP_MAX-this.capacidad)) {
			this.capacidad+=amt;
		}
	}
	public synchronized void quitarAgua(int amt) {
		if(amt<=this.capacidad) {
			this.capacidad-=amt;
			if(this.capacidad<0) {
				this.capacidad=0;
			}
		}
	}
	public synchronized int getCapacidad() {
		System.out.println(this.capacidad);
		return this.capacidad;
	}
	@Override
	public synchronized void run() {
		this.addAgua(3);
		this.quitarAgua(2);
		this.getCapacidad();
		}
	
	
}
