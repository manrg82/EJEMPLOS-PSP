package t1_Manuel.ej2;

import java.util.ArrayList;

public class GestorCubo {
	public static void main(String[] args) {
		Cubo cb=Cubo.getInstance();
		ArrayList<Thread> lista=new ArrayList<Thread>(); 
		lista.add(new Thread(cb));
		lista.add(new Thread(cb));
		lista.add(new Thread(cb));
		for(int i=0;i<lista.size();i++) {
			lista.get(i).start();
		}
		
	}
}
